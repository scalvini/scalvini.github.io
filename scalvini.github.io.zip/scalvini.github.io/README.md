# Dr Marco Scalvini

Senior Lecturer at **UAL** and **LSE**

→ **[scalvini.github.io](https://scalvini.github.io)**

[![ORCID](https://img.shields.io/badge/ORCID-0000--0002--3265--8857-a6ce39?style=flat&logo=orcid&logoColor=white)](https://orcid.org/0000-0002-3265-8857)
